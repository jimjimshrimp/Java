public class Obstacle
{
	/*
	This is an obstacle object, it has several variables.
	Type  - this is the type of object.  Currently set to only be 0 as this is a wall
			object.
	*/
	public int type = 0;
}