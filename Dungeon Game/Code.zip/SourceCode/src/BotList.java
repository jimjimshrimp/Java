import java.util.*;

public class BotList
{
	/*
	This is an ArrayList of the Bots, this stores clones of the Bots in the map.  This is
	to allow for rapid index finding of each of the Bots in the map.
	*/
	public ArrayList<Bot> botList = new ArrayList<Bot>();
}